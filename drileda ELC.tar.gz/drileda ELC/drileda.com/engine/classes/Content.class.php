<?php

class Content extends Config {
	
	public function __construct() {

		require_once 'look/temp/index.php';
	}

	static public function Body() {

		$logo = self::Logo();
		$menu = self::Menu();
		$main = self::Main();
		$footer = self::Footer();

		require_once 'look/temp/site.php';
		
		return $body;
	}

	static private function Logo() {

		$home = parent::$_home;
		$name = Init::GetConfig()['title'];

		require_once 'look/temp/logo.php';

		return $logo;
	}

	static private function Menu() {

		$site = parent::$_site;
		$home = parent::$_home;

		$frontpage = $_SESSION[$site]['frontpage'];

	    $content = (isset($_GET['content'])) ? $_GET['content'] : $frontpage;
	    $page = (isset($_GET['page'])) ? '/'.$_GET['page'] : '';
	    $op1 = (isset($_GET['op1'])) ? '/'.$_GET['op1'] : '';
	    $op2 = (isset($_GET['op2'])) ? '/'.$_GET['op2'] : '';
	    $op3 = (isset($_GET['op3'])) ? '/'.$_GET['op3'] : '';

		$c = Init::LangPart('menu');

		$lang = $_SESSION[$site]['userlang'];

		$fr = '';
		$ar = '';
		$ar2 = '';
		$ca = '';
		$ca2 = '';
		$arc = '';
		$im = '';

		$wr = '';
		$up = '';
		$de = '';
		$pi = '';
		$co = '';
		$ac = '';
		$uc = '';
		$dc = '';

		$sc = '';
		$sl = '';
		$en = '';
		
		if ($content == 'front' OR $content == $frontpage) {
			
			$fr = 'active';
		} else if ($content == 'articles') {

			$ar = 'active';
			$ar2 = 'active';
		} else if ($content == 'categories' OR $content == 'category') {

			$ca = 'active';
			$ca2 = 'active';
		} else if ($content == 'archive' OR $content == 'archive-for') {

			$arc = 'active';
		} else if ($content == 'impressions') {

			$im = 'active';
		} else if ($content == 'write') {

			$ar = 'active';
			$wr = 'active';
		} else if ($content == 'update') {

			$ar = 'active';
			$up = 'active';
		} else if ($content == 'delete') {

			$ar = 'active';
			$de = 'active';
		} else if ($content == 'pictures') {

			$ar = 'active';
			$pi = 'active';
		} else if ($content == 'comments') {

			$ar = 'active';
			$co = 'active';
		} else if ($content == 'add-category') {

			$ca = 'active';
			$ac = 'active';
		} else if ($content == 'update-category') {

			$ca = 'active';
			$uc = 'active';
		} else if ($content == 'delete-category') {

			$ca = 'active';
			$dc = 'active';
		}

		if ($lang == 'sr-ci') {

			$sc = 'active';
		} else if ($lang == 'sr-la') {

			$sl = 'active';
		} else if ($lang == 'en') {

			$en = 'active';
		}

		if ($_SESSION[$site]['usertype'] == 0) {

			require_once 'look/temp/menu0.php';
		} else if ($_SESSION[$site]['usertype'] > 0) {
			
			require_once 'look/temp/menu1.php';
		}

		return $menu;
	}

	static private function Main() {
		
		$site = parent::$_site;
		$home = parent::$_home;

		$c = Init::LangPart('main');
		$usertype = $_SESSION[$site]['usertype'];
		$lang = $userlang = $_SESSION[$site]['userlang'];

		$frontpage = $_SESSION[$site]['frontpage'];
		$content = isset($_GET['content']) ? $_GET['content'] : '';
		
		$new_a = '';
		$old_a = '';
		$new_c = '';
		$old_c = '';
		$new_arc = '';
		$old_arc = '';

		if ((isset($_GET['op1']) AND $_GET['op1'] == 'newest') OR !isset($_GET['op1'])) {

			$new_a = 'active';
		} else if (isset($_GET['op1']) AND $_GET['op1'] == 'oldest') {

			$old_a = 'active';
		}

		if ((isset($_GET['op2']) AND $_GET['op2'] == 'newest') OR !isset($_GET['op2'])) {

			$new_c = 'active';
		} else if (isset($_GET['op2']) AND $_GET['op2'] == 'oldest') {

			$old_c = 'active';
		}

		if ((isset($_GET['op3']) AND $_GET['op3'] == 'newest') OR !isset($_GET['op3'])) {

			$new_arc = 'active';
		} else if (isset($_GET['op3']) AND $_GET['op3'] == 'oldest') {

			$old_arc = 'active';
		}

		if (file_exists('engine/inc/'.$content.'.inc.php') AND $content != 'article' AND $content != 'front') {

			require_once 'engine/inc/'.$content.'.inc.php';

			return $output;
		} else if ($content == 'sent-message') {

			return "
				<h1>$c[success]</h1>
				<p>$c[sent_message]</p>
			";
		} else if ($content == 'delete-success') {

			return "
				<h1>$c[success]</h1>
				<p>$c[delete_success]</p>
			";
		} else if ($content == 'update-art-success') {

			return "
				<h1>$c[success]</h1>
				<p>$c[update_art_success]</p>
			";
		} else if ($content == 'write-art-success') {

			return "
				<h1>$c[success]</h1>
				<p>$c[write_art_success]</p>
			";
		} else if ($content == 'delete-comm-success') {

			return "
				<h1>$c[success]</h1>
				<p>$c[delete_comm_success]</p>
			";
		} else if ($content == 'add-cat-success') {

			return "
				<h1>$c[success]</h1>
				<p>$c[add_cat_success]</p>
			";
		} else if ($content == 'delete-category') {

			return "
				<h1>$c[success]</h1>
				<p>$c[del_cat_success]</p>
			";
		} else if ($content == 'front' OR $content == '') {

			$link = new DB();
			$query = "SELECT * FROM Articles JOIN Categories ON Articles.cat = Categories.catid JOIN Users ON Articles.author = Users.userid AND Articles.seo = ?";
			$result = $link->GetRow($query, [$frontpage]);
			
			require_once 'engine/inc/front.inc.php';

			return $output;
		} else {

			$link = new DB();
			$query = "SELECT * FROM Articles JOIN Categories ON Articles.cat = Categories.catid JOIN Users ON Articles.author = Users.userid AND Articles.seo = ?";
			$result = $link->GetRow($query, [$content]);

			if (empty($result)) {

				return "<h1>$c[no_content]</h1>";
			} else {
				
				require_once 'engine/inc/article.inc.php';

				return $output;
			}
		}
	}

	static private function Footer() {
		
		$site = parent::$_site;
		$home = parent::$_home;

		$lang = $_SESSION[$site]['userlang'];

		$c = Init::LangPart('main');

		if ($_SESSION[$site]['usertype'] == 0) {

			return "<p>Copyright &copy; 2017. drileda.com | <a href='".$home.$lang.'/signin'."'>$c[signin]</a></p>";
		} else if ($_SESSION[$site]['usertype'] > 0) {

			return "<p>Copyright &copy; 2017. drileda.com | ".$_SESSION[$site]['username'].', '."<a href='".$home.$lang.'/logout'."'>$c[signout]</a></p>";
		}
	}
}

?>