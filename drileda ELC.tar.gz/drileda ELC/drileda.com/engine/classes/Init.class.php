<?php

class Init extends Config {
	
	public function __construct() {

		if (session_id() === '') {

			session_start();
			ob_start();
		} else {

			ob_start();
		}
	}

	public function Start() {

		$site = parent::$_site;
		$frontpage = self::GetFrontPage();

		if (isset($_COOKIE[$site])) {

			if (isset($_SESSION[$site])) {

				// ok
			} else {
				
				$data = self::GetDataFromCookie();

				if ($data === false) {

					die('In your cookie is error. Restart browser or delete cache!');
				} else {
					
					$_SESSION[$site] = array(

						'session'	=> $data['session'],
						'userlang'	=> $data['userlang'],
						'usertype'	=> $data['usertype'],
						'username'	=> $data['username'],
						'frontpage'	=> $frontpage
					);
				}
			}
		} else {

			if (isset($_SESSION[$site])) {

				// ok
			} else {

				$_SESSION[$site] = array(

					'session'	=> md5(microtime(TRUE)),
					'userlang'	=> parent::$_userlang,
					'usertype'	=> 0,
					'username'	=> '',
					'frontpage'	=> $frontpage
				);
			}
		}
	}

	public function Lang() {

		$site = parent::$_site;

		if (isset($_GET['lang']) AND $_GET['lang'] == 'en') {
			
			$_SESSION[$site]['userlang'] = 'en';
		}
		if (isset($_GET['lang']) AND $_GET['lang'] == 'sr-ci') {
			
			$_SESSION[$site]['userlang'] = 'sr-ci';
		}
		if (isset($_GET['lang']) AND $_GET['lang'] == 'sr-la') {
			
			$_SESSION[$site]['userlang'] = 'sr-la';
		}
	}

	static public function LangPart($part) {

		$site = parent::$_site;

		if ($_SESSION[$site]['userlang'] == 'en') {
			
			require 'languages/en/'.$part.'.php';
		} else if ($_SESSION[$site]['userlang'] == 'sr-ci' OR $_SESSION[$site]['userlang'] == 'sr-la') {

			require 'languages/sr/'.$part.'.php';
		} else {

			require 'languages/sr/'.$part.'.php';
		}

		return $c;
	}

	static private function GetDataFromCookie() {

		$site = parent::$_site;

		$link = new DB();
		$query = "SELECT * FROM Users WHERE session = ?";
		$result = $link->GetRow($query, [$_COOKIE[$site]]);

		if (empty($result)) {

			return false;
		} else {

			return $result;
		}
	}

	static public function GetFrontPage() {

		$link = new DB();
		$query = "SELECT frontpage FROM Config";
		$result = $link->GetRow($query);

		return $result['frontpage'];
	}

	static public function GetConfig() {

		$site = parent::$_site;

		$link = new DB();
		$query = "SELECT * FROM Config WHERE userlang = ?";
		$result = $link->GetRow($query, [$_SESSION[$site]['userlang']]);

		return $result;
	}
}

?>