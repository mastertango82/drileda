<?php

class Engine extends Config {
	
	static public function Pagination($page, $num_page, $folder) {
		
		$site = parent::$_site;
		$home = parent::$_home;
		$lang = $_SESSION[$site]['userlang'];

		$op1 = isset($_GET['op1']) ? '/'.$_GET['op1'] : '';
		$op2 = isset($_GET['op2']) ? '/'.$_GET['op2'] : '';
		$op3 = isset($_GET['op3']) ? '/'.$_GET['op3'] : '';
		
		if ($folder == '') {

			$path = $_GET['content'];
			$or = $op1;
		} else if ($folder == 'category') {

			$path = $_GET['content'].'/'.$_GET['page'];
			$or = $op2;
		} else if ($folder == 'archive') {

			$path = $_GET['content'].'/'.$_GET['page'].'/'.$_GET['op1'];
			$or = $op3;
		}

		$pag1 = "<div id='pagi'>";
		$pag2 = '';

		for($i=1; $i<=$num_page; $i++) {
			
			if($i == $page) {
				
				$pag2 .= "&nbsp;".$i."&nbsp;";
			} else {
				
				$pag2 .= "&nbsp;<a href='".$home.$lang.'/'.$path.'/'.$i.$or."'>".$i."</a>&nbsp;";
			}
		}
		
		$pag3 = '</div>';

		return $pag1.$pag2.$pag3;
	}

	static public function Message($email, $impress) {

		$home = parent::$_home;
		$site = parent::$_site;
		$lang = $_SESSION[$site]['userlang'];

		mail("office@skupra.org", "$email", $impress);

		header("Location: $home$lang".'/sent-message');
	}

	static public function Signin($username, $password, $remember) {

		$c = Init::LangPart('main');
		$home = parent::$_home;
		$site = parent::$_site;

		$link = new DB();
		$query = "SELECT * FROM Users WHERE username = ? AND password = ?";
		$result = $link->GetRow($query, [$username, md5($password)]);

		if (empty($result)) {
			
			return $c['no_user'];
		} else {

			$frontpage = Init::GetFrontPage();

			$_SESSION[$site] = array(

				'session'	=> $result['session'],
				'userlang'	=> $result['userlang'],
				'usertype'	=> $result['usertype'],
				'username'	=> $result['username'],
				'frontpage'	=> $frontpage
			);

			if ($remember == 1) {

				setcookie($site, $result['session'], time()+3600*24*30, '/');
			}

			header("Location: $home");
		}
	}

	static public function AddComment($datetimes, $comm, $article, $user, $type) {

		$link = new DB();
		$site = parent::$_site;

		$query = "INSERT INTO Comments (datetimes, comment, artid, user, usertype) VALUES (?, ?, ?, ?, ?)";
		$result = $link->InsertRow($query, [$datetimes, $comm, $article, $user, $type]);
	}

	static public function SelectBox($cat_id) {

		$link = new DB();
		$site = parent::$_site;

		$query = "SELECT * FROM Categories";
		$result = $link->GetRows($query);

		$output = '';

		foreach ($result as $cat) {
			
			if ($_SESSION[$site]['userlang'] === 'sr-ci' OR $_SESSION[$site]['userlang'] === 'sr-la') {
				
				$cat_name = 'cat_name_sr';
			} else {
				
				$cat_name = 'cat_name_en';
			}

			if ($cat_id != '') {
				
				if ($cat['catid'] == $cat_id) {
					
					$selected = 'selected';
				} else {
					
					$selected = '';
				}
			} else {
				
				$selected = '';
			}
			
			$output .= "
				<option value='$cat[catid]' $selected>$cat[$cat_name]</option>
			";
		}

		return $output;
	}

	static public function UserId($username) {

		$site = parent::$_site;

		$link = new DB();
		$query = "SELECT userid FROM Users WHERE username = ?";
		$result = $link->GetRow($query, [$username]);

		if (!empty($result)) {
			
			return $result['userid'];
		} else {
			
			return false;
		}
	}

	static private function SEO($input) {

		$cyr = array (
			"А" => "a", "Б" => "b", "В" => "v", "Г" => "g", "Д" => "d", "Ђ" => "dj", "Е" => "e", "Ж" => "z", "З" => "z", "И" => "i", 
			"Ј" => "j", "К" => "k", "Л" => "l", "Љ" => "lj", "М" => "m", "Н" => "n", "Њ" => "nj", "О" => "o", "П" => "p", "Р" => "r", 
			"С" => "s", "Т" => "t", "Ћ" => "c", "У" => "u", "Ф" => "f", "Х" => "h", "Ц" => "c", "Ч" => "c", "Џ" => "dz", "Ш" => "s", 

			"а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "ђ" => "dj", "е" => "e", "ж" => "z", "з" => "z", "и" => "i", 
			"ј" => "j", "к" => "k", "л" => "l", "љ" => "lj", "м" => "m", "н" => "n", "њ" => "nj", "о" => "o", "п" => "p", "р" => "r", 
			"с" => "s", "т" => "t", "ћ" => "c", "у" => "u", "ф" => "f", "х" => "h", "ц" => "c", "ч" => "c", "џ" => "dz", "ш" => "s"
		);

		$output = strtr($input, $cyr);
		$output = strtolower($output);
		$output = preg_replace("/[\s]/", "-", $output);
		$output = preg_replace("/[^a-z0-9-_]/",'',$output);

		return $output;
	}

	static public function WriteArticle($header_sr, $header_en, $seo, $category_id, $body_sr, $body_en, $multilang, $see_info, $see_com, $front) {

		$site = parent::$_site;
		$home = parent::$_home;
		
		$lang = $_SESSION[$site]['userlang'];

		$c = Init::LangPart('main');
		
		$adate = date("Y-m-d");
		$authorid = self::UserId($_SESSION[$site]['username']);
		$header_sr = htmlspecialchars($header_sr, ENT_QUOTES);
		$header_en = htmlspecialchars($header_en, ENT_QUOTES);
		$seo = self::SEO($seo);

		$date = date("d-m-Y");
		$seo = $seo.'-'.$date;

		$link = new DB();
		$query0 = "SELECT * FROM Articles WHERE seo = ?";
		$result0 = $link->GetRow($query0, [$seo]);

		if (empty($result0)) {

			$query = "INSERT INTO Articles (seo, header_sr, body_sr, header_en, body_en, adate,
											cat, author, multilang, see_info, see_com) 
					VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			$result = $link->InsertRow($query, [$seo, $header_sr, $body_sr, $header_en, $body_en, $adate, 
											$category_id, $authorid, $multilang, $see_info, $see_com]);


			if ($result == 1) {
					
				$query2 = "UPDATE Categories SET numart = numart + 1 WHERE catid = ?";
				$result2 = $link->UpdateRow($query2, [$category_id]);

				if ($result2 == 1) {
					
					if ($front == 1) {
						
						$query3 = "UPDATE Config SET frontpage = ?";
						$result3 = $link->UpdateRow($query3, [$seo]);

						if ($result3 > 0) {
						
							header("Location: $home$lang".'/write-art-success');
							exit();
						}
					}
				}

				if ($result2 > 0) {
					
					header("Location: $home$lang".'/write-art-success');
					exit();
				}
			}
		} else {
			
			return $c['seo_exists'];
		}
	}

	static public function UpdateArticle($author_id, $articleid, $header_sr, $header_en, $seo, $category_id, $body_sr, $body_en, $multilang, $see_info, $see_com, $front) {

		$site = parent::$_site;
		$home = parent::$_home;
		
		$c = Init::LangPart('main');

		$lang = $_SESSION[$site]['userlang'];
		
		$header_sr = htmlspecialchars($header_sr, ENT_QUOTES);
		$header_en = htmlspecialchars($header_en, ENT_QUOTES);
		$seo = self::SEO($seo);

		$link = new DB();

		$query0 = "SELECT * FROM Articles WHERE seo = ? AND articleid != ?";
		$result0 = $link->GetRow($query0, [$seo, $articleid]);

		if (empty($result0)) {

			$query = "UPDATE Articles SET seo = ?, header_sr = ?, header_en = ?, body_sr = ?, body_en = ?, cat = ?, 
							multilang = ?, see_info = ?, see_com = ? WHERE articleid = ?";

			$result = $link->UpdateRow($query, [$seo, $header_sr, $header_en, $body_sr, $body_en, $category_id, 
							$multilang, $see_info, $see_com, $articleid]);

			if ($front == 1) {

				$query_f = "UPDATE Config SET frontpage = ?";
				$result_f = $link->UpdateRow($query_f, [$seo]);
			}

			if ($result == 1) {

				if ($_SESSION[$site]['var']['catid'] != $category_id) {

					$query2 = "UPDATE Categories SET numart = numart - 1 WHERE catid = ?";
					$result2 = $link->UpdateRow($query2, [$_SESSION[$site]['var']['catid']]);

					if ($result2 == 1) {

						$query3 = "UPDATE Categories SET numart = numart + 1 WHERE catid = ?";
						$result3 = $link->UpdateRow($query3, [$category_id]);
					}
				}

				header("Location: $home$lang".'/update-art-success');
				exit();
			}

			header("Location: $home$lang".'/update-art-success');
			exit();
		} else {
			
			return $c['seo_exists'];
		}
	}

	static public function AddCategory($cat_name_sr, $cat_name_en, $cat_desc_sr, $cat_desc_en) {

		$home = parent::$_home;
		$site = parent::$_site;

		$c = Init::LangPart('main');
		$seo = self::SEO($cat_name_sr);

		$lang = $_SESSION[$site]['userlang'];
		
		$link = new DB();
		$query = "SELECT * FROM Categories WHERE cat_seo = ?";
		$result = $link->GetRow($query, [$seo]);

		if (!empty($result)) {
			
			return $c['cat_exists'];
		} else {

			$query2 = "INSERT INTO Categories 
				(cat_seo, cat_name_sr, cat_desc_sr, cat_name_en, cat_desc_en) 
				VALUES (?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query2, [$seo, $cat_name_sr, $cat_desc_sr, $cat_name_en, $cat_desc_en]);

			if ($result > 0) {

				header("Location: $home$lang".'/add-cat-success');
			}
		}
	}

	static public function UpdateCategory($cat_name_sr_old, $cat_name_sr, $cat_name_en, $cat_desc_sr, $cat_desc_en) {

		$home = parent::$_home;
		$site = parent::$_site;

		$lang = $_SESSION[$site]['userlang'];
		
		$c = Init::LangPart('main');

		$seo = self::SEO($cat_name_sr);

		if ($cat_name_sr === $cat_name_sr_old) {
			
			$link = new DB();
			
			$query = "UPDATE Categories SET cat_name_sr = ?, cat_name_en = ?, cat_desc_sr = ?, cat_desc_en = ? WHERE catid = ?";
			$result = $link->UpdateRow($query, [$cat_name_sr, $cat_name_en, $cat_desc_sr, $cat_desc_en, $_GET['page']]);
			
			if ($result > 0) {
				
				header("Location: $home$lang".'/categories');
			}
		} else {
			
			$link = new DB();
			$query = "SELECT * FROM Categories WHERE cat_seo = ?";
			$result = $link->GetRow($query, [$seo]);

			if (!empty($result)) {
				
				return $c['cat_exists'];
			} else {
				
				$query = "UPDATE Categories SET cat_seo = ?, cat_name_sr = ?, cat_name_en = ?, cat_desc_sr = ?, cat_desc_en = ? WHERE catid = ?";
				$result = $link->UpdateRow($query, [$seo, $cat_name_sr, $cat_name_en, $cat_desc_sr, $cat_desc_en, $_GET['page']]);

				if ($result > 0) {
					
					header("Location: $home$lang".'/categories');
				}
			}
		}
	}
}

?>