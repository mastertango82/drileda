<?php

$info_en_com = "<img class='like' src='".$home.'look/img/date.png'."'> ".$en_date.' | '."<a href='".$home.$lang.'/category/'.$article['cat_seo']."'><img class='like' src='".$home.'look/img/category.png'."'> ".$article['cat_name_en']."</a>".' | '."<img class='like' src='".$home.'look/img/author.png'."'> ".$article['username'].' | '."<a href='".$home.$lang.'/'.$article['seo']."'><img class='like' src='".$home.'look/img/comments.png'."'> $total</a>";

$info_en = "<img class='like' src='".$home.'look/img/date.png'."'> ".$en_date.' | '."<a href='".$home.$lang.'/category/'.$article['cat_seo']."'><img class='like' src='".$home.'look/img/category.png'."'> ".$article['cat_name_en']."</a>".' | '."<img class='like' src='".$home.'look/img/author.png'."'> ".$article['username'];

$info_sr_com = "<img class='like' src='".$home.'look/img/date.png'."'> ".$sr_date.' | '."<a href='".$home.$lang.'/category/'.$article['cat_seo']."'><img class='like' src='".$home.'look/img/category.png'."'> ".$article['cat_name_sr']."</a>".' | '."<img class='like' src='".$home.'look/img/author.png'."'> ".$article['username'].' | '."<a href='".$home.$lang.'/'.$article['seo']."'><img class='like' src='".$home.'look/img/comments.png'."'> $total</a>";

$info_sr = "<img class='like' src='".$home.'look/img/date.png'."'> ".$sr_date.' | '."<a href='".$home.$lang.'/category/'.$article['cat_seo']."'><img class='like' src='".$home.'look/img/category.png'."'> ".$article['cat_name_sr']."</a>".' | '."<img class='like' src='".$home.'look/img/author.png'."'> ".$article['username'];

?>