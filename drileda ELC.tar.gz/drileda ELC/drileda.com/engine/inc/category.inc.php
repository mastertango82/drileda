<?php

$op1 = isset($_GET['op1']) ? $_GET['op1'] : 1;

$link = new DB();

$query0 = "SELECT COUNT(*) FROM Articles JOIN Categories ON Articles.cat = Categories.catid AND Categories.cat_seo = ?";
$result0 = $link->GetRow($query0, [$_GET['page']]);
$total = ($result0['COUNT(*)']);

if ($total > 0) {

	$limit = 10;
	$start = $limit * ($op1 - 1);
	$num_page = ceil($total / $limit);

	if (isset($_GET['op2']) AND $_GET['op2'] === 'oldest') {

		$query = "SELECT * FROM Articles JOIN Categories ON Articles.cat = Categories.catid JOIN Users ON Articles.author = Users.userid AND Categories.cat_seo = ? ORDER BY articleid ASC LIMIT $start, $limit";
	} else {

		$query = "SELECT * FROM Articles JOIN Categories ON Articles.cat = Categories.catid JOIN Users ON Articles.author = Users.userid AND Categories.cat_seo = ? ORDER BY articleid DESC LIMIT $start, $limit";
	}

	$result = $link->GetRows($query, [$_GET['page']]);

	$out1 = '';

	foreach ($result as $article) {

		$query2 = "SELECT COUNT(*) as total FROM Comments WHERE artid = ?";
		$total = $link->GetRow($query2, [$article['articleid']]);
		$total = $total['total'];

		$ed = explode ('-', $article['adate']);
		$en_date = $ed[1].'.'.$ed[2].'.'.$ed[0];
		$sr_date = $ed[2].'.'.$ed[1].'.'.$ed[0];

		require 'engine/scripts/info.php';

		if ($userlang == 'en') {

			if ($article['see_com'] == 1) {
		
				$info = $info_en_com;
			} else {

				$info = $info_en;
			}
			
			$header = $article['header_en'];
			$cat = $article['cat_name_en'];

			if ($article['multilang'] == 1) {

				$body = 'body_en';
			} else {

				$body = 'body_sr';
			}
		} else {

			if ($article['see_com'] == 1) {
		
				$info = $info_sr_com;
			} else {
				
				$info = $info_sr;
			}
			
			$header = $article['header_sr'];
			$cat = $article['cat_name_sr'];
			$body = 'body_sr';
		}

		$out1 .= 
		"
			<h3>$info</h3>
			<h1><a href='".$home.$lang.'/'.$article['seo']."'>$header</a></h1>
			$article[$body]
			<div class='hr'></div>
		";
	}

	$output = 
	"
		<h1>$c[category] $cat</h1>
		<div class='dropdown2'>
			<button class='dropbtn2'>$c[order]</button>
			<div class='dropdown-content2'>
				<a class='$new_c' href='".$home.$lang.'/'.$content.'/'.$_GET['page'].'/'.$op1.'/newest'."'>$c[newest]</a>
				<a class='$old_c' href='".$home.$lang.'/'.$content.'/'.$_GET['page'].'/'.$op1.'/oldest'."'>$c[oldest]</a>
			</div>
		</div>
	".$out1;

	$pagi = Engine::Pagination($op1, $num_page, 'category');
	$output = $output.$pagi;
} else {

	$output = "<h1>$c[empty_cat]</h1>";
}

?>