<?php

if ($usertype == 1) {

	if (isset($_GET['page'])) {

		$link = new DB();

		$query = "DELETE FROM Categories WHERE numart = ? AND catid = ?";
		$result = $link->DeleteRow($query, [0, $_GET['page']]);

		if ($result > 0) {
			
			header("Location: $home$lang".'/delete-category');
		}
	}

	$link = new DB();
	$query = "SELECT * FROM Categories ORDER BY catid ASC";
	$result = $link->GetRows($query);

	$output = "<h1>$c[delete_cat]</h1>";
	$output .= "<p><b>$c[del_cat_not]</b></p>";

	if ($_SESSION[$site]['userlang'] === 'sr-ci' OR $_SESSION[$site]['userlang'] === 'sr-la') {

		$cat_name = 'cat_name_sr';
	} else {
		
		$cat_name = 'cat_name_en';
	}

	foreach ($result as $cat) {

		$output .= "<p>$c[category] <a href='".$home.$lang.'/delete-category/'.$cat['catid']."'><b>$cat[$cat_name] ($cat[numart])</b></a></p>";
	}
} else {
	
	$output = "<h1>$c[protected]</h1>";
}

?>