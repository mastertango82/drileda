<?php

if ($usertype == 1) {
	
	if (isset($_POST['submit'])) {
		
		$commid = $_POST['id'];
		
		$link = new DB();
		$query = "DELETE FROM Comments WHERE commid = ?";
		$result = $link->DeleteRow($query, [$commid]);

		if ($result == 1) {
			
			header("Location: $home$lang".'/delete-comm-success');
		}
	}

	$output = "<h1>$c[comments]</h1>";

	$link = new DB();
	$query = "SELECT COUNT(*) FROM Comments";
	$result = $link->GetRow($query);
	$total = ($result['COUNT(*)']);

	$limit = 10;

	$page = isset($_GET['page']) ? $_GET['page'] : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);

	$query1 = "SELECT * FROM Comments ORDER BY commid DESC LIMIT $start, $limit";
	$result1 = $link->GetRows($query1);

	if (!empty($result1)) {

		foreach ($result1 as $com) {

			$output .= "<p><b>$com[commid]</b> | $com[user] | $com[usertype]<br>
			$com[comment]
			<div class='hr'></div>			
			</p>";
		}

		$output .= "
			<form action='' method='post'>
				<p class='red'>$c[delete_number_c]</p>
				<input type='text' name='id' maxlength='10' class='field4'> 
				 <input type='submit' name='submit' value='$c[confirm]' class='butt1'>
			</form>
		";
		
		$output .= Engine::Pagination($page, $num_page, '');
	} else {

		$output = "<h1>$c[no_content]</h1>";
	}
} else {
	
	$output = "<h1>$c[protected]</h1>";
}