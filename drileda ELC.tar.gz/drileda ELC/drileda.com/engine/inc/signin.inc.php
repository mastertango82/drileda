<?php

if ($usertype == 0) {
	
	$error = '';
	
	if (isset($_POST['submit'])) {

		$username = $_POST['username'];
		$password = $_POST['password'];

		$remember = isset($_POST['remember']) ? 1 : 0;

		if (empty($username) OR empty($password)) {

			$error = $c['empty'];
		} else {

			$error = Engine::Signin($username, $password, $remember);
		}
	}

	$output = "
		<h1>$c[signin]</h1>
		<p class='red'>$error</p>
		<form action='' method='post'>
		$c[username]<br>
		<input type='text' name='username' maxlength='20' class='field1'><br><br>
		$c[password]<br>
		<input type='password' name='password' maxlength='20' class='field1'><br><br>
		$c[remember]
		<input type='checkbox' name='remember' checked>
		<input type='submit' name='submit' class='butt1' value='$c[confirm]'>
		</form>
	";

} else {
	
	$output = "<h1>$c[protected]</h1>";
}

?>