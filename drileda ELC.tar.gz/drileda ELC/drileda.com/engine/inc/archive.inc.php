<?php

$output0 = '';

$link = new DB();

$query = "SELECT year(adate) AS year, month(adate) AS month, COUNT(*) AS total FROM Articles GROUP BY year, month ORDER BY year DESC, month";
$result = $link->GetRows($query);

$currentyear = null;

foreach($result as $d){            
	
	if ($d['month'] == 1) {
		
		$month_d = $c['jan'];
	} else if ($d['month'] == 2) {
		
		$month_d = $c['feb'];
	} else if ($d['month'] == 3) {
		
		$month_d = $c['mar'];
	} else if ($d['month'] == 4) {
		
		$month_d = $c['apr'];
	} else if ($d['month'] == 5) {
		
		$month_d = $c['maj'];
	} else if ($d['month'] == 6) {
		
		$month_d = $c['jun'];
	} else if ($d['month'] == 7) {
		
		$month_d = $c['jul'];
	} else if ($d['month'] == 8) {
		
		$month_d = $c['avg'];
	} else if ($d['month'] == 9) {
		
		$month_d = $c['sep'];
	} else if ($d['month'] == 10) {
		
		$month_d = $c['okt'];
	} else if ($d['month'] == 11) {
		
		$month_d = $c['nov'];
	} else if ($d['month'] == 12) {
		
		$month_d = $c['dec'];
	}

	if ($currentyear != $d['year']){
		
		$output0 .= "<h2>".$d['year']."</h2>";
		$currentyear = $d['year'];
	}

	$output0 .= "<a href='".$home.$lang.'/archive-for/'.$d['year'].'/'.$d['month']."'>$month_d | $d[total]</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}

if ($output0 == '') {

	$output = "<h1>$c[no_content]</h1>";
} else {

	$output = "
		<h1>$c[archive]</h1>
		<p>
		$output0
		</p>
	";
}

?>