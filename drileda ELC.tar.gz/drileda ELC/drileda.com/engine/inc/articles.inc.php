<?php

$page = isset($_GET['page']) ? $_GET['page'] : 1;

$link = new DB();

$query0 = "SELECT COUNT(*) FROM Articles";
$result0 = $link->GetRow($query0);
$total = ($result0['COUNT(*)']);

$limit = 10;
$start = $limit * ($page - 1);
$num_page = ceil($total / $limit);

if (isset($_GET['op1']) AND $_GET['op1'] === 'oldest') {

	$query = "SELECT * FROM Articles JOIN Categories ON Articles.cat = Categories.catid JOIN Users ON Articles.author = Users.userid ORDER BY articleid ASC LIMIT $start, $limit";
} else {

	$query = "SELECT * FROM Articles JOIN Categories ON Articles.cat = Categories.catid JOIN Users ON Articles.author = Users.userid ORDER BY articleid DESC LIMIT $start, $limit";
}

$articles = $link->GetRows($query);

$output = 
"
	<h1>$c[articles]</h1>
	<div class='dropdown2'>
		<button class='dropbtn2'>$c[order]</button>
		<div class='dropdown-content2'>
			<a class='$new_a' href='".$home.$lang.'/'.$content.'/'.$page.'/newest'."'>$c[newest]</a>
			<a class='$old_a' href='".$home.$lang.'/'.$content.'/'.$page.'/oldest'."'>$c[oldest]</a>
		</div>
	</div>
";

foreach ($articles as $article) {

	$query2 = "SELECT COUNT(*) as total FROM Comments WHERE artid = ?";
	$total = $link->GetRow($query2, [$article['articleid']]);
	$total = $total['total'];

	$ed = explode ('-', $article['adate']);
	$en_date = $ed[1].'.'.$ed[2].'.'.$ed[0];
	$sr_date = $ed[2].'.'.$ed[1].'.'.$ed[0];

	require 'engine/scripts/info.php';
	
	if ($userlang == 'en') {

		if ($article['see_com'] == 1) {
		
			$info = $info_en_com;
		} else {

			$info = $info_en;
		}

		$header = $article['header_en'];

		if ($article['multilang'] == 1) {

			$body = 'body_en';
		} else {

			$body = 'body_sr';
		}
	} else {

		if ($article['see_com'] == 1) {
		
			$info = $info_sr_com;
		} else {
			
			$info = $info_sr;
		}
		
		$header = $article['header_sr'];
		$body = 'body_sr';
	}

	$output .= "
		<h3>$info</h3>
		<h1><a href='".$home.$lang.'/'.$article['seo']."'>$header</a></h1>
		$article[$body]
		<div class='hr'></div>
	";
}

$pagi = Engine::Pagination($page, $num_page, '');
$output = $output.$pagi;

?>