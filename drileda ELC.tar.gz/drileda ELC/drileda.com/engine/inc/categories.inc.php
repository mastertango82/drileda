<?php

$output = "<h1>$c[categories]</h1>";

$link = new DB();
$query = "SELECT * FROM Categories ORDER BY catid DESC";
$result = $link->GetRows($query);

if ($lang == 'en') {

	$name = 'cat_name_en';
	$desc = 'cat_desc_en';
} else {

	$name = 'cat_name_sr';
	$desc = 'cat_desc_sr';
}

foreach ($result as $cat) {

	$output .= "
	<div class='block2'>
		<h2><a href='".$home.$lang.'/category/'.$cat['cat_seo']."'>".$cat[$name].'('.$cat['numart'].')'."</a></h2>
		<p>".$cat[$desc]."</p>
	</div>
	";
}

?>