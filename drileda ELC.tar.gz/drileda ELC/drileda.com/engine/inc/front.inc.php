<?php

$article = $result;

$query2 = "SELECT COUNT(*) as total FROM Comments WHERE artid = ?";
$total = $link->GetRow($query2, [$article['articleid']]);
$total = $total['total'];

$ed = explode ('-', $article['adate']);
$en_date = $ed[1].'.'.$ed[2].'.'.$ed[0];
$sr_date = $ed[2].'.'.$ed[1].'.'.$ed[0];

require_once 'engine/scripts/info.php';

if ($userlang == 'en') {

	if ($article['see_com'] == 1) {
		
		$info = $info_en_com;
	} else {

		$info = $info_en;
	}

	$header = $article['header_en'];

	if ($article['multilang'] == 1) {

		$body = 'body_en';
	} else {

		$body = 'body_sr';
	}
} else {

	if ($article['see_com'] == 1) {
		
		$info = $info_sr_com;
	} else {
		
		$info = $info_sr;
	}
	
	$header = $article['header_sr'];
	$body = 'body_sr';
}

if ($article['see_info'] == 1) {

	$info = $info;
} else {

	$info = '';
}

$output = "
	<h3>$info</h3>
	<h1><a href='".$home.$lang.'/'.$article['seo']."'>$header</a></h1>
	$article[$body]
";

?>