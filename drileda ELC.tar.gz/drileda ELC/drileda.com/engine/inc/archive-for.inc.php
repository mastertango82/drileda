<?php

$link = new DB();

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$op1 = isset($_GET['op1']) ? $_GET['op1'] : 1;
$op2 = isset($_GET['op2']) ? $_GET['op2'] : 1;
$op3 = isset($_GET['op3']) ? $_GET['op3'] : '';

if ($op1 == 1) {
			
	$month = $c['jan'];
} else if ($op1 == 2) {
	
	$month = $c['feb'];
} else if ($op1 == 3) {
	
	$month = $c['mar'];
} else if ($op1 == 4) {
	
	$month = $c['apr'];
} else if ($op1 == 5) {
	
	$month = $c['maj'];
} else if ($op1 == 6) {
	
	$month = $c['jun'];
} else if ($op1 == 7) {
	
	$month = $c['jul'];
} else if ($op1 == 8) {
	
	$month = $c['avg'];
} else if ($op1 == 9) {
	
	$month = $c['sep'];
} else if ($op1 == 10) {
	
	$month = $c['okt'];
} else if ($op1 == 11) {
	
	$month = $c['nov'];
} else if ($op1 == 12) {
	
	$month = $c['dec'];
}

$query0 = "SELECT COUNT(*) FROM Articles WHERE year(adate) = ? AND month(adate) = ?";
$result0 = $link->GetRow($query0, [$_GET['page'], $_GET['op1']]);
$total = ($result0['COUNT(*)']);

if ($total > 0) {

	$limit = 10;

	$start = $limit * ($op2-1);

	$num_page = ceil($total/$limit);

	$category = 'archive';

	if ($op3 === 'oldest') {
		
		$query = "SELECT * FROM Articles JOIN Users ON Articles.author = Users.userid JOIN Categories ON Articles.cat = Categories.catid AND year(adate) = ? AND month(adate) = ? ORDER BY articleid ASC LIMIT $start, $limit";
	} else {
		
		$query = "SELECT * FROM Articles JOIN Users ON Articles.author = Users.userid JOIN Categories ON Articles.cat = Categories.catid AND year(adate) = ? AND month(adate) = ? ORDER BY articleid DESC LIMIT $start, $limit";
	}

	$result = $link->GetRows($query, [$page, $op1]);

	$out1 = '';

	foreach ($result as $article) {

		$query2 = "SELECT COUNT(*) as total FROM Comments WHERE artid = ?";
		$total = $link->GetRow($query2, [$article['articleid']]);
		$total = $total['total'];

		$ed = explode ('-', $article['adate']);
		$en_date = $ed[1].'.'.$ed[2].'.'.$ed[0];
		$sr_date = $ed[2].'.'.$ed[1].'.'.$ed[0];

		require 'engine/scripts/info.php';

		if ($userlang == 'en') {

			if ($article['see_com'] == 1) {
		
				$info = $info_en_com;
			} else {

				$info = $info_en;
			}	
			
			$header = $article['header_en'];
			$cat = $article['cat_name_en'];

			if ($article['multilang'] == 1) {

				$body = 'body_en';
			} else {

				$body = 'body_sr';
			}
		} else {

			if ($article['see_com'] == 1) {
		
				$info = $info_sr_com;
			} else {
				
				$info = $info_sr;
			}
			
			$header = $article['header_sr'];
			$cat = $article['cat_name_sr'];
			$body = 'body_sr';
		}

		$out1 .= 
		"
			<h3>$info</h3>
			<h1><a href='".$home.$lang.'/'.$article['seo']."'>$header</a></h1>
			$article[$body]
			<div class='hr'></div>
		";
	}

	$output = 
	"
		<h1>$c[archive_for] $month</h1>
		<div class='dropdown2'>
			<button class='dropbtn2'>$c[order]</button>
			<div class='dropdown-content2'>
				<a class='$new_arc' href='".$home.$lang.'/'.$content.'/'.$page.'/'.$op1.'/'.$op2.'/newest'."'>$c[newest]</a>
				<a class='$old_arc' href='".$home.$lang.'/'.$content.'/'.$page.'/'.$op1.'/'.$op2.'/oldest'."'>$c[oldest]</a>
			</div>
		</div>
	".$out1;

	$pagi = Engine::Pagination($op2, $num_page, 'archive');
	$output = $output.$pagi;
} else {

	$output = "<h1>$c[empty_arc]</h1>";
}

?>
