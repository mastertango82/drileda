<?php

$article = $result;

$query2 = "SELECT COUNT(*) as total FROM Comments WHERE artid = ?";
$total = $link->GetRow($query2, [$article['articleid']]);
$total = $total['total'];

$ed = explode ('-', $article['adate']);
$en_date = $ed[1].'.'.$ed[2].'.'.$ed[0];
$sr_date = $ed[2].'.'.$ed[1].'.'.$ed[0];

require_once 'engine/scripts/info.php';

if ($userlang == 'en') {
	
	if ($article['see_com'] == 1) {
		
		$info = $info_en_com;
	} else {

		$info = $info_en;
	}

	$header = $article['header_en'];

	if ($article['multilang'] == 1) {

		$body = 'body_en';
	} else {

		$body = 'body_sr';
	}
} else {

	if ($article['see_com'] == 1) {
		
		$info = $info_sr_com;
	} else {
		
		$info = $info_sr;
	}

	$header = $article['header_sr'];
	$body = 'body_sr';
}

if (isset($_POST['submit'])) {

	$comm = htmlspecialchars($_POST['comm'], ENT_QUOTES);

	$datetimes = date("Y-m-d H:i:s");
	$artic = $article['articleid'];
	
	if ($usertype == 1) {
		
		$user = $_SESSION[$site]['username'];
	} else {

		$user = htmlentities($_POST['user']);
	}

	if (!empty($comm) AND !empty($user)) {
		
		if ($usertype == 0) {
			
			if ($_SESSION[$site]['var']['result2'] == $_POST['result2']) {
				
				$add_comm = Engine::AddComment($datetimes, $comm, $artic, $user, 0);
				header("Location: ".$home.$lang.'/'.$content);
			}	
		} else {
			
			$add_comm = Engine::AddComment($datetimes, $comm, $artic, $user, 1);
			header("Location: ".$home.$lang.'/'.$content);
		}
	}
}

if ($article['see_com'] == 1) {

	$query1 = "SELECT * FROM Comments JOIN Articles ON Comments.artid = Articles.articleid AND Articles.seo = ? ORDER BY commid DESC";
	$result1 = $link->GetRows($query1, [$content]);

	$allcomm = '';

	foreach ($result1 as $comm) {

		$viewdateq = explode (' ', $comm['datetimes']);

		$viewdate = $viewdateq[0];
		$time = $viewdateq[1];

		$viewdate = explode ('-',$viewdate);
		$viewdate = $viewdate[2].'.'.$viewdate[1].'.'.$viewdate[0];

		$time = explode(':', $time);
		$time = $time[0].':'.$time[1];

		$viewdateall = $viewdate.' - '.$time;

		if ($comm['usertype'] == 1) {

			$allcomm .= "<p class='red'>$comm[user] | $viewdateall | <b>$comm[comment]</b></p>";
		} else {
			
			$allcomm .= "<p>$comm[user] | $viewdateall | <b>$comm[comment]</b></p>";
		}
	}

	if ($usertype == 1) {
			
		$allcomcom = 
		"
			<div class='hr'></div>
			<p>$c[comm]</p>
			<form action='' method='post'>
			<textarea class='field3' name='comm' maxlength='200'></textarea><br><br>
			<input type='submit' class='butt1' name='submit' value='$c[confirm]'>
			</form>
			$allcomm
		";
	} else {
		
		$o1 = rand (0, 5);
		$o2 = rand (0, 5);

		$_SESSION[$site]['var']['result2'] = $o1 + $o2;
		
		$allcomcom = 
		"
			<div class='hr'></div>
			<p>$c[comm]</p>
			<form action='' method='post'>
			$c[username_user]:<br>
			<input type='text' name='user' maxlength='20' class='field1'><br><br>
			<textarea class='field3' name='comm' maxlength='200'></textarea><br><br>
			$o1 + $o2 = <input type='text' name='result2' class='field4'><br><br>
			<input type='submit' class='butt1' name='submit' value='$c[confirm]'>
			</form>
			$allcomm
		";	
	}

	$output = 
	"
		<h3>$info</h3>
		<h1>$header</h1>
		$article[$body]
		$allcomcom
	";
} else {

	$output = 
	"
		<h3>$info</h3>
		<h1>$header</h1>
		$article[$body]
	";
}	

?>