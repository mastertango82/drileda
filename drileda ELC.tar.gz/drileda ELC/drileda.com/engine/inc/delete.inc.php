<?php

if ($usertype == 1) {
	
	$error = '';

	if (isset($_POST['submit'])) {
		
		$articleid = $_POST['id'];
		
		$link = new DB();

		$query0 = "SELECT cat FROM Articles WHERE articleid = ?";
		$result0 = $link->GetRow($query0, [$articleid]);
		$catid = $result0['cat'];

		$query1 = "SELECT * FROM Config";
		$result1 = $link->GetRow($query1);
		$frontpage = $result1['frontpage'];

		$query = "DELETE FROM Articles WHERE articleid = ? AND seo != ?";
		$result = $link->DeleteRow($query, [$articleid, $frontpage]);

		if ($result == 1) {
				
			$query2 = "UPDATE Categories SET numart = numart - 1 WHERE catid = ?";
			$result2 = $link->UpdateRow($query2, [$catid]);

			if ($result2 == 1) {
				
				header("Location: $home$lang".'/delete-success');
			}
		} else {

			$error = $c['no_front'];
		}	
	}

	$link = new DB();

	$query0 = "SELECT COUNT(*) FROM Articles";

	$result0 = $link->GetRow($query0);
	$total = ($result0['COUNT(*)']);

	$limit = 10;

	$page = isset($_GET['page']) ? $_GET['page'] : 1;

	$start = $limit * ($page-1);

	$num_page = ceil($total/$limit);

	$query = "SELECT * FROM Articles JOIN Users ON Articles.author = Users.userid ORDER BY articleid DESC LIMIT $start, $limit";
	$result = $link->GetRows($query);

	$output = 
	"
		<h1>$c[delete_articles]</h1>
		<p class='red'>$error</p>
	";

	if (!empty($result)) {

		foreach ($result as $article) {
			$output .= "
				<p>$article[username] | <b>$article[articleid]</b> | $article[adate] | $article[seo] | $article[header_sr] | $article[header_en]</p>
			";
		}

		$output .= "
			<form action='' method='post'>
				<p class='red'>$c[delete_number]</p>
				<input type='text' name='id' maxlength='10' class='field4'> 
				 <input type='submit' name='submit' value='$c[confirm]' class='butt1'>
			</form>
		";
		
		$output .= Engine::Pagination($page, $num_page, '');
	} else {
		
		$output = "<h1>$c[no_content]</h1>";
	}
} else {
	
	$output = "<h1>$c[protected]</h1>";
}

?>