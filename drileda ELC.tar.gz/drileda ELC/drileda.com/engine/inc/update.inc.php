<?php

if ($usertype == 1) {
	
	if (isset($_GET['op1'])) {
		
		$error = '';

		$output = "
			<h1>$c[update_article]</h1>
		";
		
		if (substr($_GET['op1'], -7) === '_update') {

			$articleid = substr($_GET['op1'], 0, -7);
			
			if (isset($_POST['submit'])) {

            	if (!empty($_POST['header_sr']) 
                AND !empty($_POST['header_en']) 
                AND !empty($_POST['seo']) 
                AND !empty($_POST['category_id']) 
                AND !empty($_POST['body_sr'])) {

	                $header_sr = $_POST['header_sr'];
	                $header_en = $_POST['header_en'];
	                $seo = $_POST['seo'];
	                $category_id = $_POST['category_id'];
	                $body_sr = $_POST['body_sr'];

	                $multilang = (isset($_POST['multilang'])) ? 1 : 0;
	                $see_info = (isset($_POST['see_info'])) ? 1 : 0;
	                $see_com = (isset($_POST['see_com'])) ? 1 : 0;
	                $front = (isset($_POST['front'])) ? 1 : 0;

	                $body_en = $_POST['body_en'];

	                $author_id = $_POST['author_id'];

	                $error = Engine::UpdateArticle($author_id, $articleid, $header_sr, $header_en, $seo, $category_id, $body_sr, $body_en, $multilang, $see_info, $see_com, $front);
	            } else {
	                
	                $error = $c['empty'];
	            }
       		}

			$link = new DB();

			if ($_SESSION[$site]['username'] == 'admin') {

				$query = "SELECT * FROM Articles JOIN Users ON Articles.author = Users.userid JOIN Config ON 1 = 1 AND Articles.articleid = ?";
				$result = $link->GetRow($query, [$articleid]);
			} else {
				
				$query = "SELECT * FROM Articles JOIN Users ON Articles.author = Users.userid JOIN Config ON 1 = 1 AND Articles.articleid = ? AND Users.username = ?";
				$result = $link->GetRow($query, [$articleid, $_SESSION[$site]['username']]);
			}

			$_SESSION[$site]['var']['catid'] = $result['cat'];
			
			if (!empty($result)) {

				$selectbox = Engine::SelectBox($result['cat']);

				$body_sr = htmlentities($result['body_sr']);
				$body_en = htmlentities($result['body_en']);

				if ($result['multilang'] == 1) {
					
					$checked_mul = 'checked';
				} else {
					
					$checked_mul = '';
				}

				if ($result['see_info'] == 1) {
					
					$checked_inf = 'checked';
				} else {
					
					$checked_inf = '';
				}

				if ($result['see_com'] == 1) {
					
					$checked_com = 'checked';
				} else {
					
					$checked_com = '';
				}

				if ($result['frontpage'] == $result['seo']) {
					
					$checked_fro = 'checked';
				} else {
					
					$checked_fro = '';
				}

					$output .= "

				        <p class='red'>$error</p>
						<form action='' method='post'>
				        $c[header_sr](*):<br>
				        <input type='text' name='header_sr' class='field1' maxlength='128' value='$result[header_sr]'><br><br>
				        $c[header_en](*):<br>
				        <input type='text' name='header_en' class='field1' maxlength='128' value='$result[header_en]'><br><br>
				        $c[seo_header](*):<br>
				        <input type='text' name='seo' class='field1' maxlength='128' value='$result[seo]'><br><br>
				        $c[category](*): 
				        <select class='selbox1' name='category_id'>
				        $selectbox
				        </select><br><br>
				        $c[body_sr](*)<br>
				        <textarea id='edit' name='body_sr'>$body_sr
				        </textarea><br><br>
				        $c[multilang]: <input type='checkbox' $checked_mul name='multilang'><br><br>
				        $c[body_en]<br>
				        <textarea id='edit' name='body_en'>$body_en
				        </textarea><br><br>
				        $c[see_info]: <input type='checkbox' $checked_inf name='see_info'><br>
				        $c[see_com]: <input type='checkbox' $checked_com name='see_com'><br>
				        $c[front]: <input type='checkbox' $checked_fro name='front'><br><br>
				        <input type='hidden' name='author_id' value='$result[author]'>
				        <input type='submit' name='submit' class='butt1' value='$c[confirm]'>
						</form>
						<script src='".$home."engine/tinymce/tinymce.min.js'></script>
				  		<script>tinymce.init({
				        relative_urls : false,
				        remove_script_host : true,
				        document_base_url : '".$home."',
				        content_css : '".$home.'look/css/style.css'."',
				  selector: 'textarea',
				  height: 400,
				  theme: 'modern',
				  plugins: [
				    'advlist autolink lists link image charmap print preview hr anchor pagebreak',
				    'searchreplace wordcount visualblocks visualchars code fullscreen',
				    'insertdatetime media nonbreaking save table contextmenu directionality',
				    'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
				  ],
				  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
				  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
				  image_advtab: true,
				  templates: [
				    { title: 'Test template 1', content: 'Test 1' },
				    { title: 'Test template 2', content: 'Test 2' }
				  ]
				 });</script>
					";
			}
		}
	} else {		

		$link = new DB();

		if ($_SESSION[$site]['username'] == 'admin') {
			
			$query0 = "SELECT COUNT(*) FROM Articles JOIN Users ON Articles.author = Users.userid";
			$result0 = $link->GetRow($query0);
		} else {

			$query0 = "SELECT COUNT(*) FROM Articles JOIN Users ON Articles.author = Users.userid AND Users.username = ?";
			$result0 = $link->GetRow($query0, [$_SESSION[$site]['username']]);	
		}

		$total = ($result0['COUNT(*)']);
		$limit = 3;
		$page = isset($_GET['page']) ? $_GET['page'] : 1;
		$start = $limit * ($page-1);
		$num_page = ceil($total/$limit);
		
		if ($_SESSION[$site]['username'] == 'admin') {

			$query = "SELECT * FROM Articles JOIN Users ON Articles.author = Users.userid ORDER BY articleid DESC LIMIT $start, $limit";
			$result = $link->GetRows($query);
		} else {
			
			$query = "SELECT * FROM Articles JOIN Users ON Articles.author = Users.userid AND Users.username = ? ORDER BY articleid DESC LIMIT $start, $limit";
			$result = $link->GetRows($query, [$_SESSION[$site]['username']]);
		}

		if (!empty($result)) {
			
			$output = "
				<h1>$c[update_articles]</h1>
			";

			foreach ($result as $article) {

				$output .= "<p><b>$article[username]</b> | $article[articleid] | $article[adate] | <a href='".$home.$lang.'/update/article/'.$article['articleid'].'_update'."'>$article[seo]</a> | $article[header_sr] | $article[header_en]</p>";
			}

			$output .= Engine::Pagination($page, $num_page, '');
		} else {

			$output = "<h1>$c[no_content]</h1>";
		}
	}
} else {

	$output = "<h1>$c[protected]</h1>";
}

?>