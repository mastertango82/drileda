<?php

$error = '';

if (isset($_POST['submit'])) {

	$email = htmlentities($_POST['email']);
	$impress = htmlentities($_POST['impress']);

	if (empty($email) OR empty($impress)) {

		$error = $c['empty'];
	} else {

		Engine::Message($email, $impress);
	}
}

$output = "
	<h1>$c[impressions]</h1>
	<p class='red'>$error</p>
	<form action='' method='post'>
	$c[em_nam_hed]<br>
	<input type='text' name='email' maxlength=64 class='field1'><br><br>
	$c[message]<br>
	<textarea name='impress' class='field2' maxlength='400'></textarea><br><br>
	<input type='submit' name='submit' class='butt1' value='$c[confirm]'>
	</form>
";

?>