<?php

class Config {

	static protected $_host			= 'localhost';
	static protected $_username		= 'skupraor_drileda';
	static protected $_password		= 'Riko9854';
	static protected $_database		= 'skupraor_drileda';

	static protected $_site			= 'driledaorg';
	static protected $_home			= '/';
	static protected $_url			= 'http://www.drileda.com/';
	
	static protected $_style		= '/look/css/style.css';
	static protected $_favicon		= '/favicon.png';

	static protected $_userlang		= 'sr-ci';
}

?>
