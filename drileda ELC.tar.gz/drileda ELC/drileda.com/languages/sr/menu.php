<?php

$c = array(
	
	'frontpage'			=> 'Фронт',
	'articles'			=> 'Чланци',
	'categories'		=> 'Категорије',
	'archive'			=> 'Архива',
	'impressions'		=> 'Утисци',
	'language'			=> 'Језик',
	'serbian_cy'		=> 'Ћирилица',
	'serbian_la'		=> 'Латиница',
	'english'			=> 'Енглески',
	'see_articles'		=> 'Види чланке',
	'write'				=> 'Напиши чланак',
	'update'			=> 'Ажурирај чланак',
	'delete'			=> 'Избриши чланак',
	'pictures'			=> 'Слике',
	'see_categories'	=> 'Види категорије',
	'add_category'		=> 'Додај категорију',
	'update_category'	=> 'Ажурирај категорију',
	'delete_category'	=> 'Избриши категорију',
	'comments'			=> 'Коментари'
);

?>