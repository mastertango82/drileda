<?php

$c = array(

	'frontpage'			=> 'Front',
	'articles'			=> 'Articles',
	'categories'		=> 'Categories',
	'archive'			=> 'Archive',
	'impressions'		=> 'Impressions',
	'language'			=> 'Language',
	'serbian_cy'		=> 'SR Cyrillic',
	'serbian_la'		=> 'SR Latinic',
	'english'			=> 'English',
	'see_articles'		=> 'See articles',
	'write'				=> 'Write article',
	'update'			=> 'Update article',
	'delete'			=> 'Delete article',
	'pictures'			=> 'Pictures',
	'see_categories'	=> 'See categories',
	'add_category'		=> 'Add category',
	'update_category'	=> 'Update category',
	'delete_category'	=> 'Delete category',
	'comments'			=> 'Comments'
);

?>