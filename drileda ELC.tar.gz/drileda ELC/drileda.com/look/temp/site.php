<?php

$body = "
	<div id='all'>
		<div id='logo'>
		$logo
		</div>
		<div id='menu'>
		$menu
		</div>
		<div class='clear'></div>
		<div id='main'>
		$main
		</div>
		<div id='footer'>
		$footer
		</div>
	</div>
";

?>