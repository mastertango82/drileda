<?php

$menu = "
	<a class='dropbtn $fr' href='".$home.$lang.'/front'."'>$c[frontpage]</a>
	<div class='dropdown'>
		<a href='#' class='dropbtn $ar'>$c[articles]</a>
		<div class='dropdown-content'>
			<a class='$ar2' href='".$home.$lang.'/articles'."'>$c[see_articles]</a>
			<a class='$wr' href='".$home.$lang.'/write'."'>$c[write]</a>
			<a class='$up' href='".$home.$lang.'/update'."'>$c[update]</a>
			<a class='$de' href='".$home.$lang.'/delete'."'>$c[delete]</a>
			<a class='$pi' href='".$home.$lang.'/pictures'."'>$c[pictures]</a>
			<a class='$co' href='".$home.$lang.'/comments'."'>$c[comments]</a>
		</div>
	</div>
	<div class='dropdown'>
		<a href='#' class='dropbtn $ca'>$c[categories]</a>
		<div class='dropdown-content'>
			<a class='$ca2' href='".$home.$lang.'/categories'."'>$c[see_categories]</a>
			<a class='$ac' href='".$home.$lang.'/add-category'."'>$c[add_category]</a>
			<a class='$uc' href='".$home.$lang.'/update-category'."'>$c[update_category]</a>
			<a class='$dc' href='".$home.$lang.'/delete-category'."'>$c[delete_category]</a>
		</div>
	</div>
	<a class='dropbtn $arc' href='".$home.$lang.'/archive'."'>$c[archive]</a>
	<a class='dropbtn $im' href='".$home.$lang.'/impressions'."'>$c[impressions]</a>
	<div class='dropdown'>
		<a href='#' class='dropbtn'>$c[language]</a>
		<div class='dropdown-content'>
			<a class='$sc' href='".$home.'sr-ci/'.$content.$page.$op1.$op2.$op3."'>$c[serbian_cy]</a>
			<a class='$sl' href='".$home.'sr-la/'.$content.$page.$op1.$op2.$op3."'>$c[serbian_la]</a>
			<a class='$en' href='".$home.'en/'.$content.$page.$op1.$op2.$op3."'>$c[english]</a>
		</div>
	</div>
";

?>