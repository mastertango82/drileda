<?php

$menu = "
	<a class='dropbtn $fr' href='".$home.$lang.'/front'."'>$c[frontpage]</a>
	<a class='dropbtn $ar' href='".$home.$lang.'/articles'."'>$c[articles]</a>
	<a class='dropbtn $ca' href='".$home.$lang.'/categories'."'>$c[categories]</a>
	<a class='dropbtn $arc' href='".$home.$lang.'/archive'."'>$c[archive]</a>
	<a class='dropbtn $im' href='".$home.$lang.'/impressions'."'>$c[impressions]</a>
	<div class='dropdown'>
		<a href='#' class='dropbtn'>$c[language]</a>
		<div class='dropdown-content'>
			<a class='$sc' href='".$home.'sr-ci/'.$content.$page.$op1.$op2.$op3."'>$c[serbian_cy]</a>
			<a class='$sl' href='".$home.'sr-la/'.$content.$page.$op1.$op2.$op3."'>$c[serbian_la]</a>
			<a class='$en' href='".$home.'en/'.$content.$page.$op1.$op2.$op3."'>$c[english]</a>
		</div>
	</div>
";

?>