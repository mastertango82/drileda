<?php

$logo = "
	<a href='".$home."'>
	<img id='logo_img' src='".$home."look/img/drileda_logo.png'></a>
	<h1><a href='".$home."'>$name</a></h1>
";

?>