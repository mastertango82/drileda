<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';
require_once 'engine/classes/Init.class.php';
require_once 'engine/classes/DB.class.php';
require_once 'engine/classes/Decode.class.php';
require_once 'engine/classes/Content.class.php';
require_once 'engine/classes/Engine.class.php';

$init = new Init();
$init->Start();
$init->Lang();

$decode = new Decode;
echo $decode->Output();

?>