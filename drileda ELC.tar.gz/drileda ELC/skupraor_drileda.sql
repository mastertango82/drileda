-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 11, 2017 at 06:27 PM
-- Server version: 10.0.32-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skupraor_drileda`
--

-- --------------------------------------------------------

--
-- Table structure for table `Articles`
--

CREATE TABLE `Articles` (
  `articleid` int(11) NOT NULL,
  `adate` date NOT NULL DEFAULT '2017-09-30',
  `seo` varchar(128) NOT NULL,
  `cat` int(11) NOT NULL,
  `author` int(11) NOT NULL,
  `header_sr` varchar(128) NOT NULL,
  `body_sr` text NOT NULL,
  `header_en` varchar(128) NOT NULL,
  `body_en` text NOT NULL,
  `multilang` int(1) NOT NULL DEFAULT '0',
  `see_info` int(1) NOT NULL DEFAULT '1',
  `see_com` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Articles`
--

INSERT INTO `Articles` (`articleid`, `adate`, `seo`, `cat`, `author`, `header_sr`, `body_sr`, `header_en`, `body_en`, `multilang`, `see_info`, `see_com`) VALUES
(7, '2017-10-08', 'manifest-08-10-2017', 1, 1, 'Манифест', '<blockquote>\r\n<p style=\"text-align: left;\">Поштовани,<br />добро дошли на наш сајт.</p>\r\n</blockquote>\r\n<p style=\"text-align: left;\">Овде се ради о нама и Вама. Ми постојимо да би Вама дан био испуњенији. Надамо се да ће те наћи <strong>Вама</strong> занимљиве ствари. Такође, и да ће те нам се враћати са осмехом и знатижељом.</p>\r\n<p style=\"text-align: left;\">Овај сајт је настао из потребе да Вам нешто лепо кажемо. Да са Вама поделимо наше знање, наше недоумице и наше идеје. Није нам намера никога да омаловажавамо ни ти да се било коме лично обраћамо.</p>\r\n<p style=\"text-align: left;\">Наш посао је готов, онда када вам у глави буде одзвањало \"дриледа, дриледа, дриледа...\".</p>\r\n<p style=\"text-align: left;\"><strong>Шта је заправо дриледа?</strong></p>\r\n<p style=\"text-align: left;\"><strong>Дриледа</strong> је заједнички блог неколико аутора. Пишемо оно што знамо или мислимо да знамо. Желимо да останемо анонимни, јер само тако можете видети све наше стране личности, а да ми сами не будемо угрожени.</p>\r\n<p style=\"text-align: left;\">Надамо се да разумете... &gt;&gt;&gt; Када сте на сцени морате причати оно што публика жели да чује, не би ли добили овације. Када сте писац, пишете оно што мислите, да би ваши читаоци у вама видели идола, икону и искрено вас волели због ваше искрености. А када сте <strong>анонимни блогер</strong>, онда пишете и оно што мислите и оно што не мислите и једини вам је циљ да вас људи читају и препознају по ставу.</p>\r\n<p style=\"text-align: left;\">Ми смо све то скупа. Анонимност је релативна ствар. <strong>Али оно што истичемо то је да се не истичемо.</strong></p>\r\n<p style=\"text-align: left;\"><em>Први наш текст...Срећно!</em></p>', 'Manifest', '', 0, 0, 0),
(10, '2017-10-10', 'sloboda-10-10-2017', 4, 1, 'Слобода', '<p>Ноћ је у мојој глави. Бесомучна ноћ која опија. Срце нам свим дрхти, као да је онај исти дан слободе, коју смо тако слепо чекали. Слобода се не чека, слобода се осваја. Наше мисли су тог дана биле упрте у ваше недужне мозгове, који су се раширили по целом платну белине. Па од вас осташе само сиве мрље и по мало зависности.<br /><br /><strong>Слобода</strong> је реч коју употребљавају људи кад желе да други мисле како су јаки. Не. Ми нисмо јаки, нисмо неустрашиви али смо слободни. И ту слободу смо освојили и крвљу и сузама и знањем. Можда пушкама, тенковима, Боговима. Не знам чиме све нисмо. И зато је тако јака. Та, слобода.<br /><br />Толико је јака наша слобода <strong>да се не опиремо да уперимо прст</strong> у свакога и да му кажемо: \"Ти ниси слободан, ти си нечије власништво.\"<br /><br />Јако је лепо кад имате ту моћ, да управљате људима. Да им делите лекције и да их уздижете и спуштате на нивое који вама одговарају. Још је лепше кад имате ту моћ владања, а не користите је. <strong>Замислите</strong>, људи вам дају цео свет а ви кажете,</p>\r\n<blockquote>\"НЕ, хоћу само делић хлеба и неба.\"</blockquote>\r\n<p><br /><br />Та слобода је неуништива, непресушна и постојана, јер само она оставља неке норме људскости и самопоштовања. Сви сте дошли у трен када вам је све на дохват руке, па вам просто буде горак укус у устима јер имате све то и све то једнако мрзите. Мрзите зато што вам је поклоњено а не зарадили.<br /><br />Зарадити слободу је исто као скувати тек обрано млеко. Не смеш да журиш а не смеш ни да доцниш. У једном случају, млеко ће бити бљутаво, у другом - биће пуно нереда на шпорету.<br /><br />Ето то вам пишем ја који и не знам да спремам те ручкове, али знам да зарадим. Слободу, мисао, реч, поглед.<br /><br />Јако је тешко кад на једној обали реке видиш само пустахињу и корење, а на твојој обали видиш раскош и срећу. Тебе мозак ипак вуче на ту другу обалу.<strong> Ма, није то мозак, то је срце</strong>. Не знам. Вуче те и желиш да освојиш ту другу обалу, да је улепшаш и ако знаш да кад одеш, нећеш више моћи да се вратиш.<br /><br />Знате шта је још теже, теже је то што осим те друге обале ми откривамо трећу. Кад успемо да обистинимо и упознамо ту трећу обалу реке, тада ће цео свет бити наш. А наш посао ће бити само да то делимо другима по заслузи. То је слобода.</p>', 'Freedom', '', 0, 1, 1),
(11, '2017-10-10', 'manevar-10-10-2017', 4, 2, 'Manevar', '<p><span style=\"font-weight: 400;\">Umeće ratovanja</span></p>\r\n<p><span style=\"font-weight: 400;\">***</span></p>\r\n<p><span style=\"font-weight: 400;\">(Sun Tzu) Manevar</span></p>\r\n<h2><strong>VII</strong></h2>\r\n<p><strong>MANEVAR</strong></p>\r\n<p>&nbsp;<strong><em>Sun Tzu</em></strong><span style=\"font-weight: 400;\"> kaže:</span></p>\r\n<ul>\r\n<li style=\"font-weight: 400;\"><span style=\"font-weight: 400;\"> Kad vojska stupi u rat, general prvo primi zapovied od svog vladara. General prikuplja jedinice i mobilizuje narod. On od vojske napravi </span><em><span style=\"font-weight: 400;\">skladno</span></em><span style=\"font-weight: 400;\"> telo i ulogori se.</span></li>\r\n</ul>\r\n<p>&nbsp;<strong>Li Ouan:</strong><span style=\"font-weight: 400;\"> &nbsp;</span><em><span style=\"font-weight: 400;\">Njega vladar opunomoći da, na temelju odluka hramskog veća (predefinisano: upravnog odbora) o pobedama koje treba izboriti, postane izvr&scaron;itelj kazne koju odredi Nebo.</span></em>&nbsp;</p>\r\n<ul>\r\n<li style=\"font-weight: 400;\"><span style=\"font-weight: 400;\">Najteže umeće je umeće manevrisanja. U manevru je najteže to &scaron;to zaobilazni put moramo učiniti najpristupacnijim i te&scaron;koće moramo pretvoriti u svoje prednosti.</span></li>\r\n<li style=\"font-weight: 400;\"><span style=\"font-weight: 400;\">Dakle, idemo poznatim (najpristupacnijojim) stazama i skrećemo neprijatelja dezinformacijom gde mi hoćemo. Na taj način možemo krenuti i posle njega, a stići pre njega. Kad znamo postupak, &nbsp;onda možemo reći da smo ovladali strategijom pristupacog (izracunatog) &nbsp;i nepristupacnog.</span></li>\r\n</ul>\r\n<p><span style=\"font-weight: 400;\">Pro</span><span style=\"font-weight: 400;\">č</span><span style=\"font-weight: 400;\">itati detaljnije u knjizi: </span><em><span style=\"font-weight: 400;\">Dojam </span></em><strong>(izluziju)</strong><em><span style=\"font-weight: 400;\"> &hellip;. posle neprijatelja i stici pre njega &ndash; </span></em><strong><em>Cao Cao</em></strong></p>\r\n<p><span style=\"font-weight: 400;\">Doslovno pi&scaron;e: &raquo;borba&laquo; ili &raquo;poraz vojske&laquo;, budući da se svako bori za poziciju u kojoj će imati prednost.</span></p>\r\n<p><span style=\"font-weight: 400;\">Re</span><span style=\"font-weight: 400;\">č</span><span style=\"font-weight: 400;\">enica je prevedena tragom </span><strong><em>Li Quana</em></strong><span style=\"font-weight: 400;\"> i </span><strong><em>Jia Lina</em></strong><span style=\"font-weight: 400;\">, a možei </span><strong><em>&raquo; On tako ulogoruje vojsku koja je najkompitabilnija medjusobno &laquo;</em></strong><span style=\"font-weight: 400;\">, prema </span><strong><em>Cao Caou</em></strong><span style=\"font-weight: 400;\"> i </span><strong><em>Du Muu</em></strong><span style=\"font-weight: 400;\">. Kad prikupi vojsku, zapovednik je mora organizovati ili </span><strong><em>&raquo; uskladiti njene različite elemente &laquo;</em></strong></p>\r\n<p><strong><em>***</em></strong></p>\r\n<p><strong><em>SunTzu::OG(hightech)</em></strong></p>\r\n<p>&nbsp;</p>', 'Manevar', '', 0, 1, 1),
(12, '2017-10-10', 'pismo-autorima-10-10-2017', 1, 1, 'Писмо ауторима', '<p>Показало се сврсисходно да кажемо коју реч о новим ауторима.</p>\r\n<p>Сваким даном, наш <strong>тим аутора</strong> расте, али нека правила морамо поштовати.</p>\r\n<ol>\r\n<li><strong>Наслов чланка пишете ћирилицом</strong></li>\r\n<li>Наслов морате превести на енглески</li>\r\n<li>Текст пишете <strong>обавезно</strong> на ћирилици. Само у ванредним случајевима ћемо толерисати другачије.</li>\r\n<li>СЕО линк<strong> (SEO)</strong> пишете латиницом и то је такорећи српски наслов са цртицама уместо празних поља. Пример:<br />\"umece-ratovanja\" или \"nezaobilazni-put-u-novo\" <strong>(Систем ће додати датум)</strong></li>\r\n<li><strong>Вишејезичност</strong> штиклирајте ако желите да пишете и на енглеском. Нештиклирано поље, значи, да се увек приказује само српска верзија текста.</li>\r\n<li><strong>Инфо, Коментари и Фронт</strong> углавном, остају тако како је намештено. Ако желите неку тему на <strong>Фронт</strong> страни, штиклирате Фронт. Али то је посао за главног админа. На Фронт страни може бити само један чланак. Ако не желите коментаре на ваш чланак, одштиклирајте \"Коменатри\". Инфо, је ставка за Фронт страну, ако је одштиклирана, значи да се не приказују на Фронт страни подаци о категорији, аутору, датуму, већ само главни наслов и текст.</li>\r\n<li>Ускоро убацујемо и слике. Потребна нам је класа за слике, да би биле добро поравнате.</li>\r\n</ol>\r\n<p>Толико за сада. Админ</p>', 'Letter to authors', '', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Categories`
--

CREATE TABLE `Categories` (
  `catid` int(11) NOT NULL,
  `cat_seo` varchar(128) NOT NULL,
  `cat_name_sr` varchar(128) NOT NULL,
  `cat_desc_sr` text NOT NULL,
  `cat_name_en` varchar(128) NOT NULL,
  `cat_desc_en` text NOT NULL,
  `numart` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Categories`
--

INSERT INTO `Categories` (`catid`, `cat_seo`, `cat_name_sr`, `cat_desc_sr`, `cat_name_en`, `cat_desc_en`, `numart`) VALUES
(1, 'info-pult', 'Инфо Пулт', 'Ова категорија је намењена за чланке који су у вези самог сајта и нашег рада. Информације о сајту и нашем раду.', 'Info Desk', 'This category is for articles related to the site itself and our work. Site information and our work.', 2),
(4, 'osnovna', 'Основна', 'Основна категорија. За сад, једина категорија за нове текстове, јер их нема много. Кад се прича прошири, додаћемо и друге.', 'Basic', 'Basic category. For now, the only category for new texts, because there are not many. When the story is expanded, we will add others.', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Comments`
--

CREATE TABLE `Comments` (
  `commid` int(11) NOT NULL,
  `artid` int(11) NOT NULL,
  `datetimes` datetime NOT NULL DEFAULT '2017-10-01 21:32:00',
  `usertype` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Comments`
--

INSERT INTO `Comments` (`commid`, `artid`, `datetimes`, `usertype`, `comment`, `user`) VALUES
(5, 11, '2017-10-10 17:51:43', 1, 'Компликован је твој мозак :)', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `Config`
--

CREATE TABLE `Config` (
  `confid` int(11) NOT NULL,
  `userlang` varchar(8) NOT NULL,
  `frontpage` varchar(128) NOT NULL,
  `html_lang` varchar(8) NOT NULL,
  `charset` varchar(8) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `author` varchar(64) NOT NULL,
  `title` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Config`
--

INSERT INTO `Config` (`confid`, `userlang`, `frontpage`, `html_lang`, `charset`, `description`, `keywords`, `author`, `title`) VALUES
(1, 'en', 'manifest-08-10-2017', 'en', 'utf-8', '...', '...', 'Milos Toplicic', 'Drileda'),
(2, 'sr-ci', 'manifest-08-10-2017', 'sr', 'utf-8', '...', '...', 'Милош Топличић', 'Дриледа'),
(3, 'sr-la', 'manifest-08-10-2017', 'sr', 'utf-8', '...', '...', 'Miloš Topličić', 'Drileda');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `userid` int(11) NOT NULL,
  `usertype` int(1) NOT NULL DEFAULT '1',
  `userlang` varchar(8) NOT NULL,
  `session` varchar(32) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`userid`, `usertype`, `userlang`, `session`, `username`, `password`, `email`) VALUES
(1, 1, 'sr-ci', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'eaffecb06da03653ad77647cda8457c2', 'admin@drileda.org'),
(2, 1, 'sr-ci', '18496d77c7c18eee4c65a0f9985f8001', 'hightech', '0c850325161757b216932c66e6bcebe8', ''),
(3, 1, 'sr-ci', '260145bcc926f44dcbc36d90be54f90a', 'vulevubg', '2ccdcf8d59eccb3b6a6c141cacb9ccaf', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Articles`
--
ALTER TABLE `Articles`
  ADD PRIMARY KEY (`articleid`);

--
-- Indexes for table `Categories`
--
ALTER TABLE `Categories`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `Comments`
--
ALTER TABLE `Comments`
  ADD PRIMARY KEY (`commid`);

--
-- Indexes for table `Config`
--
ALTER TABLE `Config`
  ADD PRIMARY KEY (`confid`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Articles`
--
ALTER TABLE `Articles`
  MODIFY `articleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `Categories`
--
ALTER TABLE `Categories`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Comments`
--
ALTER TABLE `Comments`
  MODIFY `commid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Config`
--
ALTER TABLE `Config`
  MODIFY `confid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
